// ==================================================
// 🔑 PERMISSÃO DE SOBREPOSIÇÃO (ESSENCIAL PARA O APP)
// ==================================================
document.addEventListener('DOMContentLoaded', async () => {
    console.log('🎱 Iniciando Painel 8 Ball Pool...');
    
    // Verifica se está rodando como App Android
    if (window.Android && window.Android.requestOverlayPermission) {
        try {
            await window.Android.requestOverlayPermission();
            console.log('✅ Permissão de sobreposição concedida!');
        } catch (err) {
            console.log('⚠️ Conceda a permissão manualmente:');
            console.log('Configurações → Aplicativos → [Nome do App] → Sobrepor outros apps → ATIVAR ✅');
        }
    } else {
        console.log('ℹ️ Modo navegador — permissão de sobreposição disponível só no App compilado');
    }
});

// ==================================================
// 🎯 CONTROLE DA BOLHA FLUTUANTE
// ==================================================
const bubble = document.getElementById('floatingBubble');
const toggleBtn = document.getElementById('toggleBtn');
const bubbleContent = document.getElementById('bubbleContent');
const header = bubble.querySelector('.bubble-header');

// Minimizar / Maximizar
toggleBtn.addEventListener('click', () => {
    bubbleContent.classList.toggle('collapsed');
    toggleBtn.textContent = bubbleContent.classList.contains('collapsed') ? '+' : '−';
});

// ==================================================
// 👆 ARRASTAR A BOLHA (TOQUE + MOUSE — CORRIGIDO!)
// ==================================================
let isDragging = false;
let offsetX = 0;
let offsetY = 0;

// Início do arrasto — TOQUE
header.addEventListener('touchstart', (e) => {
    isDragging = true;
    const touch = e.touches[0];
    const rect = bubble.getBoundingClientRect();
    offsetX = touch.clientX - rect.left;
    offsetY = touch.clientY - rect.top;
    bubble.style.transition = 'none';
});

// Início do arrasto — MOUSE
header.addEventListener('mousedown', (e) => {
    isDragging = true;
    offsetX = e.clientX - bubble.getBoundingClientRect().left;
    offsetY = e.clientY - bubble.getBoundingClientRect().top;
    bubble.style.transition = 'none';
});

// Função de mover — CORRIGIDA (sem erro "e is not defined")
function moveBubble(clientX, clientY) {
    if (!isDragging) return;
    
    let newX = clientX - offsetX;
    let newY = clientY - offsetY;

    // Não deixa sair da tela
    const maxX = window.innerWidth - bubble.offsetWidth;
    const maxY = window.innerHeight - bubble.offsetHeight;
    
    newX = Math.max(0, Math.min(newX, maxX));
    newY = Math.max(0, Math.min(newY, maxY));

    bubble.style.left = newX + 'px';
    bubble.style.top = newY + 'px';
    bubble.style.right = 'auto';
}

// Movimento — TOQUE
document.addEventListener('touchmove', (e) => {
    e.preventDefault();
    moveBubble(e.touches[0].clientX, e.touches[0].clientY);
}, { passive: false });

// Movimento — MOUSE
document.addEventListener('mousemove', (e) => {
    moveBubble(e.clientX, e.clientY);
});

// Soltar — parar arrasto
function stopDrag() {
    isDragging = false;
    bubble.style.transition = 'all 0.1s ease';
}
document.addEventListener('touchend', stopDrag);
document.addEventListener('mouseup', stopDrag);

// ==================================================
// 📐 CANVAS PARA DESENHAR LINHAS DE MIRA
// ==================================================
const canvas = document.getElementById('aimCanvas');
const ctx = canvas.getContext('2d');

// Ajusta tamanho do canvas para tela cheia
function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

// Desenha linha de mira sobreposta
window.desenharLinha = function(x, y, angulo, comprimento) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.beginPath();
    ctx.moveTo(x, y);
    const fimX = x + Math.cos(angulo * Math.PI / 180) * comprimento;
    const fimY = y + Math.sin(angulo * Math.PI / 180) * comprimento;
    ctx.lineTo(fimX, fimY);
    ctx.strokeStyle = '#00ffcc';
    ctx.lineWidth = 3;
    ctx.shadowBlur = 15;
    ctx.shadowColor = '#00ffcc';
    ctx.stroke();
};

// Limpar todas as linhas
window.limparLinhas = function() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
};

console.log('✅ Painel 8 Ball Pool — CARREGADO COM SUCESSO!');
